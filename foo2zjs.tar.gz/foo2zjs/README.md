# foo2zjs
A linux printer driver for QPDL protocol - copy of http://foo2zjs.rkkda.com/
